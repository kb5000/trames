user_pref("layout.frame_rate", 1);
user_pref("layout.throttled_frame_rate", 1);
