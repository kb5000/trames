user_pref("layout.frame_rate", 1);
