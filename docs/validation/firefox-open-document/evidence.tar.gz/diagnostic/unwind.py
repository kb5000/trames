import sys,re,struct,bisect,io,json
from pathlib import Path
sys.path.insert(0,'/tmp/trames-firefox-elftools')
from elftools.elf.elffile import ELFFile
from elftools.dwarf.callframe import CallFrameInfo
mods={}
paths={'libxul.so':'target/firefox/libxul.so','firefox':'target/firefox/firefox','libc.so':'target/musl-hybrid/libc.so','libglib-2.0.so.0.8400.4':'/tmp/trames-firefox-libglib.so','libnspr4.so':'/tmp/trames-firefox-libnspr4.so','libevent-2.1.so.7.0.2':'/tmp/trames-firefox-libevent.so','libscudo.so':'target/firefox/libscudo.so'}
for name,path in paths.items():
 f=open(path,'rb');e=ELFFile(f);h=e.get_section_by_name('.eh_frame_hdr');s=e.get_section_by_name('.eh_frame');c=None;table=[]
 if h and s:
  b=h.data();assert b[:4]==bytes.fromhex('011b033b'),(path,b[:4]);n=struct.unpack_from('<I',b,8)[0]
  table=[(x+h['sh_addr'],y+h['sh_addr']-s['sh_addr']) for x,y in struct.iter_unpack('<ii',b[12:12+n*8])]
  c=CallFrameInfo(io.BytesIO(s.data()),s['sh_size'],s['sh_addr'],e.get_dwarf_info().structs,for_eh_frame=True)
 syms=[]
 for sec in ['.symtab','.dynsym']:
  st=e.get_section_by_name(sec)
  if st:syms.extend((x['st_value'],x['st_size'],x.name) for x in st.iter_symbols() if x['st_info']['type']=='STT_FUNC' and x['st_size'])
 syms.sort();mods[name]=(e,c,table,[x[0] for x in table],syms)
maps={}
for line in Path(sys.argv[1]).read_text().splitlines():
 m=re.search(r'FFMAP .*?vm=(\d+).*?path=Ok\(Node\(\[([\d, ]+)\]\)\).*?offset=(\S+) size=(\S+) prot=(\d+) ret=Some\(([\da-f]+)\)',line)
 if m:
  v,n,off,size,prot,base=m.groups(); n=Path(bytes(map(int,n.split(','))).decode()).name
  if n in mods and int(off,16)==0:maps.setdefault(int(v),[]).append((int(base,16),int(size,16),n))
def resolve(vm,pc):
 if 0x70000000<=pc<0x700f0000:return 'libc.so',pc-0x70000000,0x70000000
 if 0x40000000<=pc<0x400ab000:return 'firefox',pc-0x40000000,0x40000000
 for base,size,name in maps.get(vm,[]):
  if base<=pc<base+size:return name,pc-base,base
 for mv, entries in {}.items():
  if mv==7:continue
  for base,size,name in entries:
   if base<=pc<base+size:return name,pc-base,base
 return None,pc,0
for filename in sys.argv[2:]:
 p=Path(filename);meta=p.read_text();v,page,pc,sp=map(lambda x:int(x,0),re.search(r'vm=(\d+) page=(0x[\da-f]+) pc=(0x[\da-f]+) sp=(0x[\da-f]+)',meta).groups());regs={i:int(x.strip(),16) for i,x in enumerate(meta.split('regs=[')[1].split(']')[0].split(','))};regs[31]=sp;mem=p.with_suffix('.bin').read_bytes()
 def read(addr):
  i=addr-page
  if i<0 or i+8>len(mem):raise ValueError('outside saved stack '+hex(addr))
  return struct.unpack_from('<Q',mem,i)[0]
 print(p.name,'vm',v)
 try:
  for i in range(60):
   name,rel,base=resolve(v,pc);print(i,hex(pc),'sp='+hex(regs[31]),name or '?',hex(rel),end=' ')
   if not name:print('unresolved');break
   e,c,table,starts,syms=mods[name];sym=next((x for x in syms if x[0]<=rel<x[0]+x[1]),None);print(sym[2] if sym else '',end=' ')
   j=bisect.bisect_right(starts,rel-1)-1;ent=c._parse_entry_at(table[j][1]) if c and j>=0 else None
   if ent and not ent['initial_location']<=rel-1<ent['initial_location']+ent['address_range']:ent=None
   if ent:
    row=next(x for x in reversed(ent.get_decoded().table) if x['pc']<=rel-1);cf=row['cfa'];print('fde='+hex(ent['initial_location']),cf)
    if cf.expr:break
    cfa=regs[cf.reg]+cf.offset;new=regs.copy();new[31]=cfa
    for r,rule in row.items():
     if not isinstance(r,int):continue
     if rule.type=='OFFSET':new[r]=read(cfa+rule.arg)
     elif rule.type=='SAME_VALUE':pass
     elif rule.type=='REGISTER':new[r]=regs[rule.arg]
     elif rule.type=='UNDEFINED':new.pop(r,None)
     else:raise ValueError(str(rule))
    if 30 not in new:break
    pc=new[30];regs=new
   elif name=='libc.so':
    print('manual musl prologue')
    if rel in [0x7c2dc]:pc=regs[30];continue
    if not sym:break
    fun=sym[2];layouts={'read':(16,{30:0}),'write':(16,{30:0}),'poll':(32,{30:0}),'ppoll':(32,{30:0}),'syscall':(96,{30:0}),'sendmsg':(0x4a0,{30:0,19:8,20:16,21:24,22:32}),'__clock_gettime':(32,{30:0,19:8,20:16}),'clock_gettime':(32,{30:0,19:8,20:16}),'__syscall_cp_c':(32,{30:0,19:8,20:16}),'__timedwait_cp':(80,{30:0,19:8,20:16,21:24,22:32,23:40}),'__timedwait':(64,{30:0,19:8,20:16,21:24,22:32}),'pthread_cond_timedwait':(128,{30:0,19:8,20:16,21:24,22:32,23:40,24:48,25:56,26:64,27:72}),'__pthread_cond_timedwait':(128,{30:0,19:8,20:16,21:24,22:32,23:40,24:48,25:56,26:64,27:72})}
    if fun not in layouts:break
    size,saved=layouts[fun];new=regs.copy()
    for r,off in saved.items():new[r]=read(regs[31]+off)
    new[31]+=size;pc=new[30];regs=new
   else:print('no unwind info');break
 except Exception as ex:print(type(ex).__name__,str(ex))
